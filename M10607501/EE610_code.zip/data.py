import numpy as np
import math
import datetime
from datetime import timedelta
import common
import pandas


def time_parse(time_string):
    return datetime.datetime.strptime(time_string, TIME_FORMAT)


def time_format(t):
    return datetime.datetime.strftime(t, TIME_FORMAT)


def wind(wind_direction, wind_speed):
    if wind_direction == 999017:
        return 0., 0.
    else:
        wind_lng = wind_speed * math.cos(wind_direction / 180. * math.pi)
        wind_lat = wind_speed * math.sin(wind_direction / 180. * math.pi)
        return wind_lng, wind_lat


def features_parse(row_input):
    station_id, time, temperature, humidity, wind_direction, wind_speed = row_input
    t = time_parse(time)
    wind_lng, wind_lat = wind(wind_direction, wind_speed)
    f_std = [temperature, humidity, wind_lng, wind_lat]
    f_std = np.divide(np.subtract(f_std, avg_input), s_input)
    features = [f_std[0], f_std[1], f_std[2], f_std[3], t.hour]
    return features


def features_trace(frame, city, t, grid_name):
    t_last_day = t - timedelta(hours=HOUR_OFFSET)
    f_inside = []
    for i in range(TRACE_COUNT):
        t = t_last_day - timedelta(hours=i * HOUR_STEP)
        row_input = select_input(frame, city, time_format(t), grid_name=grid_name)
        if row_input is None:
            return None
        fi = features_parse(row_input)
        f_inside += fi
    return [f_inside]


def loc2grid(lng, lat, lng0, lat0):
    return round(10 * (21 * (lng - lng0) + (lat - lat0)))


def determine_grid_name(city, lng, lat):
    lng0 = None
    lat0 = None
    if city == CITY_BEIJING:
        lng0 = 115.
        lat0 = 39.
    elif city == CITY_LONDON:
        lng0 = -2.
        lat0 = 50.5
    return city + '_grid_' + repr(loc2grid(lng, lat, lng0, lat0)).zfill(3)


def determine_table_name(t):
    if t >= TIME_CRITICAL:
        return 'inputs_api'
    else:
        return 'inputs'


def load_inputs(csv=None):
    if csv is None:
        csv = PATH_CSV_INPUTS
    frame = pandas.read_csv(csv)
    return frame[INPUTS_COLS]


def select_input(frame, city, time, lng=115., lat=39., grid_name=None):
    if grid_name is None:
        grid_name = determine_grid_name(city, lng, lat)
    frame_time = frame[frame['time'] == time]
    results = frame_time[frame['station_id'] == grid_name].get_values()
    if len(results) < 1:
        return None
    return results[0]


def load_samples(csv=None):
    if csv is None:
        csv = PATH_CSV_SAMPLES
    frame = pandas.read_csv(csv)
    return frame[SAMPLES_COLS]


def select_samples(frame, start, count):
    return frame[start:start+count].get_values()


def filter_samples_threshold(frame):
    for i in range(OUTPUTS_COUNT):
        col = OUTPUTS_COLS[i]
        frame = frame[frame[col] > (avg_sample[i] - s_sample[i])]
        frame = frame[frame[col] < (avg_sample[i] + s_sample[i])]
    return frame


def filter_samples_nan(frame):
    for i in range(OUTPUTS_COUNT):
        col = OUTPUTS_COLS[i]
        frame = frame[not math.isnan(frame[col])] # not working
    return frame


def sql_samples_condition_not_null():
    return ' and '.join(common.dress(' %<>\'\' ', '%', OUTPUTS_COLS))


def load_locations(csv=None):
    if csv is None:
        csv = PATH_CSV_LOCATIONS
    frame = pandas.read_csv(csv)
    return frame


def select_location(frame, station_id):
    if cache_location == station_id:
        return cache_lng, cache_lat, cache_city
    results = frame[frame['station_id'] == station_id].get_values()
    if len(results) < 1:
        return None
    result = results[0]
    longitude, latitude, city = result[1], result[2], result[3]
    lng = round(longitude, 1)
    lat = round(latitude, 1)
    return lng, lat, city


def determine_city(station_id):
    if station_id is None or station_id == '':
        return None
    if station_id.isupper():
        return CITY_LONDON
    else:
        return CITY_BEIJING


def adjust(path_in, path_out, adjustment):
    csv = open(path_in, 'r')
    out = open(path_out, 'w')
    out.write(csv.readline())
    for row_string in csv:
        all_cols = row_string[:-1].split(",")
        if len(all_cols) <= 1:
            out.write(row_string)
        cols = all_cols[1:]
        for i in range(len(cols)):
            if cols[i] == '':
                continue
            # x <= a * x + b + r * random()
            a = adjustment[i][0]
            b = adjustment[i][1]
            r = adjustment[i][2]
            random = 2 * (np.random.random() - 0.5)
            x = float(cols[i]) * a + b + r * random
            if x < 0:
                x = 0
            cols[i] = repr(x)
        line = ','.join([all_cols[0]] + cols)
        out.write(line + '\n')


def average_punk(frame, path_csv, path_out):
    csv = open(path_csv, 'r')
    out = open(path_out, 'w')
    out.write(csv.readline())
    cache = {}
    cols = ['PM25_Concentration', 'PM10_Concentration', 'O3_Concentration']
    pm25_init, pm10_init, o3_init = 0., 0., 0.
    for row_string in csv:
        objective_string = row_string.split(',')[0]
        station, hour = tuple(objective_string.split('#'))
        pm25, pm10, o3 = pm25_init, pm10_init, o3_init
        if station in cache:
            pm25, pm10, o3 = tuple(cache[station])
        else:
            pm25, pm10, o3 = average_at(frame, cols, station)
            if pm25 is None:
                pm25 = pm25_init
            if pm10 is None:
                pm10 = pm10_init
            if o3 is None:
                o3 = o3_init
            cache[station] = [pm25, pm10, o3]
            pm25_init, pm10_init, o3_init = pm25, pm10, o3
        string = ''
        if len(station) == 3:
            string = ','.join([objective_string, str(pm25), str(pm10), str('')])
        else:
            string = ','.join([objective_string, str(pm25), str(pm10), str(o3)])
        out.write(string + '\n')
    csv.close()
    out.close()


def average_at(frame, cols, station):
    frame_station = frame[frame['station_id'] == station]
    averages = []
    for col in cols:
        frame_col = frame_station[col]
        values = frame_col.get_values()
        print('*** {} ***'.format(col))
        averaged = average(values)
        averages.append(averaged)
    return tuple(averages)


def average(values):
    summ = 0.
    total = 0
    for value in values:
        if not math.isnan(value):
            summ += value
            total += 1
            print('#{} : {:.1f} -> {:.1f}'.format(total, value, summ))
    if total == 0:
        return None
    print('AVERAGE:: {:.2f}'.format(summ / total))
    return summ / total


HOUR_STEP = 1
HOUR_OFFSET = 72
HOUR_STEAL = 1
TRACE_COUNT = 1
OUTPUTS_COLS = [
    'PM25_Concentration', 'PM10_Concentration', 'O3_Concentration',
    'NO2_Concentration', 'CO_Concentration', 'SO2_Concentration'
]
OUTPUTS_COUNT = len(OUTPUTS_COLS)
SAMPLES_COLS = [
    'station_id', 'time', 'PM25_Concentration', 'PM10_Concentration', 'O3_Concentration',
    'NO2_Concentration', 'CO_Concentration', 'SO2_Concentration'
]
FEATURES_COLS = [
    'temperature', 'humidity', 'wind_direction', 'wind_speed'
]
# 'temperature', 'pressure', 'humidity', 'wind_direction', 'wind_speed'
FEATURES_MORES = [
    'hour'
]
FEATURES_COUNT = len(FEATURES_COLS) + len(FEATURES_MORES)
INPUTS_COLS = ['station_id', 'time'] + FEATURES_COLS
INPUTS_COUNT = TRACE_COUNT * FEATURES_COUNT
TIME_FORMAT = '%Y-%m-%d %H:%M:%S'
TIME_CRITICAL = datetime.datetime.combine(datetime.date(2018, 4, 1), datetime.time(0, 0, 0))
CITY_BEIJING = 'beijing'
CITY_LONDON = 'london'
PATH_DB = 'kdd.db'
PATH_CKPT = 'ckpt/kdd.ckpt'
PATH_INFO = 'kdd.info'
PATH_CSV_LOCATIONS = 'locations.csv'
PATH_CSV_SAMPLES = 'samples.csv'
PATH_CSV_INPUTS = 'inputs.csv'
PATH_SUBMIT_SAMPLE = 'sample_submission.csv'
PATH_SUBMIT_CSV = 'submission.csv'
PATH_ADJUSTED_CSV = 'submission{0:+.0f}{1:+.0f}{2:+.0f}.csv'
PATH_DOWNLOADED_GRID = 'api_grid_'
PATH_DOWNLOADED_AQ = 'api_aq_'
DOWNLOAD_URL_GRID = 'https://biendata.com/competition/meteorology/'
DOWNLOAD_URL_AQ = 'https://biendata.com/competition/airquality/'
DOWNLOAD_URL_TAIL = '/2k0d1d8'
DOWNLOAD_CITY_BEIJING = 'bj'
DOWNLOAD_CITY_LONDON = 'ld'
DOWNLOAD_CITIES = [DOWNLOAD_CITY_BEIJING, DOWNLOAD_CITY_LONDON]
SUBMIT_USER_ID = 'veringsek'
SUBMIT_DESC = 'EE610'
SUBMIT_TOKEN = '1c555835c3f5f05122d653ed3f8c97cae49557d5baed6df7c1d3086ab957ba4d'
SUBMIT_URL = 'https://biendata.com/competition/kdd_2018_submit/'

# load info
info = common.read_json(PATH_INFO)
avg_sample = info['sample']['average']
s_sample = info['sample']['s']
avg_input = info['input']['average']
s_input = info['input']['s']

# cache
cache_location = None
cache_lng = None
cache_lat = None
cache_city = None
