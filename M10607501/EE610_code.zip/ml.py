import tensorflow as tf
import numpy as np
import sqlite3
import datetime
from datetime import timedelta
import data
import common


def evaluates(delta, s):
    return np.power(np.e, np.multiply(np.divide(np.abs(delta), np.divide(s, 10)), -0.1))


def pour(action, sess, structure, count, start=0, print_step=1): #, random=True):
    # action
    if action is None or action == '':
        return

    # structure
    features = structure['features']
    answers = structure['answers']
    prediction = structure['prediction']
    delta = structure['delta']
    train = structure['train']

    frame_samples = data.filter_samples_threshold(data.load_samples())
    frame_locations = data.load_locations()
    frame_inputs = data.load_inputs()
    rows_sample = data.select_samples(frame_samples, start, count)#, random=random)
    counter = 0
    rights = np.zeros(data.OUTPUTS_COUNT, dtype=np.float)
    for row_sample in rows_sample:
        counter += 1
        location_id, time = row_sample[:2]
        # list() is to avoid 'float' has no .floor attribute error
        a = [list(row_sample[2:])]
        location = data.select_location(frame_locations, location_id)
        if location is None:
            print('Location not found. ')
            continue
        lng, lat, city = location
        grid_name = data.determine_grid_name(city, lng, lat)
        f = data.features_trace(frame_inputs, city, data.time_parse(time), grid_name)
        if f is None:
            print('Input null: ', time, '@', lng, lat)
            continue
        feed_dict = {features: f, answers: a}
        p, d = None, None

        if action == 'trains':
            p, d, _ = sess.run((prediction, delta, train), feed_dict=feed_dict)
        elif action == 'verify':
            p, d = sess.run((prediction, delta), feed_dict=feed_dict)
        else:
            break
        rights = np.add(rights, evaluates(d[0], data.s_sample))
        if print_step > 0 and counter % print_step == 0:
            print('#', counter, location_id, time, '@', lng, ',', lat)
            print(': prediction:', np.floor(p[0]))
            print(': answer:    ', np.floor(a[0]))
            print(': accuracy:  ', np.floor(np.multiply(rights, 100 / counter)), '%')
            print('')


def trains(sess=None, structure=None, s=None, count=0, start=0, print_step=1, random=True):
    if s is not None:
        sess, structure = s
    pour('trains', sess=sess, structure=structure, count=count, start=start,
         print_step=print_step)#, random=random)


def verify(sess=None, structure=None, s=None, count=0, start=0, print_step=1, random=True):
    if s is not None:
        sess, structure = s
    pour('verify', sess=sess, structure=structure, count=count, start=start,
         print_step=print_step)#, random=random)


def guess(sess=None, structure=None, s=None, t=None):
    if s is not None:
        sess, structure = s

    # structure
    features = structure['features']
    prediction = structure['prediction']

    # input
    frame_locations = data.load_locations()
    frame_inputs = data.load_inputs()
    csv = open(data.PATH_SUBMIT_SAMPLE, 'r')
    out = open(data.PATH_SUBMIT_CSV, 'w')
    out.write(csv.readline())
    for row_string in csv:
        objective_string = row_string.split(',')[0]
        station, hour = tuple(objective_string.split('#'))
        hour = int(hour)
        t_hour = t + timedelta(hours=hour)
        lng, lat, city = data.select_location(frame_locations, station)
        print(station, '@', lng, lat)
        steal = -1
        f = None
        while f is None:
            steal += 1
            t_hour_steal = t_hour - timedelta(hours=data.HOUR_STEAL * steal)
            f = data.features_trace(frame_inputs, city, t_hour_steal,
                                    data.determine_grid_name(city, lng, lat))
        if steal > 0:
            print('! Stealth occurred:', steal)
        if f is None:
            print('Cannot complete mission:', objective_string, t_hour, '@', lng, lat)
            continue
        feed_dict = {features: f}
        p = sess.run(prediction, feed_dict=feed_dict)
        pm25, pm10, o3 = repr(p[0][0]), repr(p[0][1]), repr(p[0][2])
        if city == data.CITY_LONDON:
            o3 = ''
        line = ','.join([objective_string, pm25, pm10, o3])
        out.write(line + '\n')
        print(line)

